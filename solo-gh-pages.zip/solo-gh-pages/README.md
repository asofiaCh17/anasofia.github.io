## Deprecated: Use my new theme "Duo" instead:

[https://chibicode.github.io/duo/](https://chibicode.github.io/duo/)

---

# Solo

[Solo](http://chibicode.github.io/solo) is a Jekyll theme that supports **single-page websites** only, but supports them well. Yes, it's responsive.

### [Demo & Documentation &rarr;](http://chibicode.github.io/solo)
